@echo off
setlocal

REM ============================================================
REM  Scanner App - Live Preview Launcher
REM  Double-click this file to start the app in your browser.
REM ============================================================

cd /d "%~dp0"

echo.
echo ============================================================
echo   Starting Scanner App live preview...
echo ============================================================
echo.

REM Check if Node.js is installed
where node >nul 2>nul
if errorlevel 1 (
    echo [ERROR] Node.js is not installed or not in PATH.
    echo.
    echo Please install Node.js LTS from: https://nodejs.org
    echo Then run this file again.
    echo.
    pause
    exit /b 1
)

REM Install dependencies on first run
if not exist "node_modules" (
    echo First run detected - installing dependencies...
    echo This may take a minute or two.
    echo.
    call npm install
    if errorlevel 1 (
        echo.
        echo [ERROR] npm install failed. See messages above.
        pause
        exit /b 1
    )
    echo.
    echo Dependencies installed.
    echo.
)

echo ============================================================
echo   Preview will open at: http://localhost:5173
echo   Keep this window open while you work.
echo   Press Ctrl+C to stop the preview.
echo ============================================================
echo.

REM Open the browser after a short delay, then run the dev server
start "" cmd /c "timeout /t 3 /nobreak >nul && start http://localhost:5173"

call npm run dev

pause
