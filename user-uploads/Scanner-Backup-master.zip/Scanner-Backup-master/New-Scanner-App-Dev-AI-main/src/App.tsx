import InventoryScanner from "./InventoryScanner";

export default function App() {
  return <InventoryScanner />;
}
